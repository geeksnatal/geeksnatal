﻿{
	"version": 1519152364,
	"fileList": [
		"data.js",
		"c2runtime.js",
		"jquery-2.1.1.min.js",
		"offlineClient.js",
		"tiledbackground.png",
		"player-sheet0.png",
		"player-sheet1.png",
		"bulletplayer-sheet0.png",
		"enemy-sheet0.png",
		"bulletenemy-sheet0.png",
		"icon-16.png",
		"icon-32.png",
		"icon-114.png",
		"icon-128.png",
		"icon-256.png",
		"loading-logo.png",
		"logo-intro-binario.mp4",
		"logo-intro-binario.ogv",
		"logo-intro-binario.webm"
	]
}